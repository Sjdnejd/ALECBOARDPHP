<?php
	if(!defined('__AFOX__')) exit();

?>

<div class="container">

	<div class="bs-popup-body">
		<section>
			<article>
			<?php displayModule()?>
			</article>
		</section>
	</div>

</div>
