<?php
if(!defined('__AFOX__')) exit();

$_PROTECT['disp.setuppage']		= ['grant' => 's'];
$_PROTECT['disp.viewpage']		= ['grant' => '0'];

$_PROTECT['proc.deletepage']	= ['grant' => 's'];
$_PROTECT['proc.updatepage']	= ['grant' => 's'];

$_PROTECT['proc.getpage']		= ['grant' => '0'];

/* End of file protect.php */
/* Location: ./module/page/protect.php */
