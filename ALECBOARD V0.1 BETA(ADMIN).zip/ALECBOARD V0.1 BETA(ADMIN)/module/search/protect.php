<?php
if(!defined('__AFOX__')) exit();

$_PROTECT['setup']	= ['grant' => 's'];

$_PROTECT['disp.default']	= ['grant' => '0'];

$_PROTECT['proc.setupsearch']	= ['grant' => 's'];

/* End of file protect.php */
/* Location: ./module/search/protect.php */
