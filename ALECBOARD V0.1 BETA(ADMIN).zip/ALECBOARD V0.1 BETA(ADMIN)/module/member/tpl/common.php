<?php
if(!defined('__AFOX__')) exit();

addJSLang(['item','message','document','confirm_empty','confirm_delete','confirm_select_delete','confirm_select_empty']);

/* End of file common.php */
/* Location: ./module/member/tpl/common.php */
/* 이 파일이 존재하면 해당 tpl 파일을 읽기전 자동으로 가장 먼저 읽어들임   */
