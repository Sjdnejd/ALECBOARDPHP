<?php
if(!defined('__AFOX__')) exit();

/* End of file default.php */
/* Location: ./module/board/tpl/default.php */