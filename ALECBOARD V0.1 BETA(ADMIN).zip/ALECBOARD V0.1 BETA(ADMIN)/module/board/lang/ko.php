<?php
if(!defined('__AFOX__')) exit();
// 에러가 발생할 가능성이 있으니 언어에 ' (홑따옴표)는 쓰지마세요.
// 필요하면 ` (악센트) 이걸 사용하세요.

$_LANG['msg_is_secret'] = '비밀글입니다.';
$_LANG['msg_is_deleted'] = '삭제되었습니다.';
$_LANG['msg_reply_exists'] = '이 문서와 관련된 답변이 존재합니다.';
$_LANG['msg_not_write_reply'] = '더 이상 답변하실 수 없습니다.'."\n".'답변은 5단계 각 단계당 93개 까지만 가능합니다.';

/* End of file ko.php */
/* Location: ./module/board/lang/ko.php */
