<?php
if(!defined('__AFOX__')) exit();

$_MODULE_INFO['version'] = "0.1 BETA";
$_MODULE_INFO['author'] = "ALECBOARD";
$_MODULE_INFO['email'] = "joowonlee0704@gmail.com";
$_MODULE_INFO['link'] = "http://alexleejw.com";
$_MODULE_INFO['title'] = "게시판";
$_MODULE_INFO['description'] = "ALECBOARD 게시판 모듈입니다.";
$_MODULE_INFO['date'] = "2022-12-11";
/* End of file info.php */
/* Location: ./module/board/info.php */